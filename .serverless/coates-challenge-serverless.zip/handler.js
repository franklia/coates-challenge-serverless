// import serverless from 'serverless-http';
// import express from 'express';
// import bodyParser from 'body-parser';
// import cors from 'cors';
'use strict';
// import dotenv from 'dotenv';
// dotenv.config();
require('dotenv').config();
// import readline from 'readline';
const readline = require('readline');
const fs = require('fs');
// import fs from 'fs';

// create instances
// const app = express();
// const router = express.Router();

// const PORT = process.env.PORT || 3001;

// // configure the API to use bodyParser and look for JSON data in the request body
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());

// // Enable CORS
// app.use(
//   cors({
//     origin: process.env.CORS_ORIGIN,
//   })
// );

module.exports.hello = async (event) => {
  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Go Serverless v1.0! Your function executed successfully!',
        input: event,
      },
      null,
      2
    ),
  };
};

// GET array of temperature objects for 10 days from csv file
module.exports.temperatures = async (event) => {
  try {
    const rl = readline.createInterface({
      input: fs.createReadStream(`${process.env.LOCAL_PATH}/src/sydney-temperatures.csv`, 'utf8'),
      crlfDelay: Infinity,
    });

    let result = [];

    const compile = async () => {
      for await (const line of rl) {
        const lineArray = line.split(',');
        let singleObj = {};
        const obj = lineArray.map((item, index) => {
          if (index === 0) {
            singleObj['date'] = item;
          } else if (index === 1) {
            singleObj['max'] = item;
          } else {
            singleObj['min'] = item;
          }
        });
        result.push(singleObj);
      }
    };

    await compile();
    result.shift();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Origin': 'https://coates-challenge-ui.s3.amazonaws.com/index.html',
        'Access-Control-Allow-Methods': 'GET',
      },
      body: JSON.stringify(result),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ 'Error: ': err }),
    };
  }
};
// router.get('api/temperatures', async (req, res) => {
//   const rl = readline.createInterface({
//     input: fs.createReadStream(`${process.env.LOCAL_PATH}/src/sydney-temperatures.csv`, 'utf8'),
//     crlfDelay: Infinity,
//   });

//   let result = [];

//   const compile = async () => {
//     for await (const line of rl) {
//       const lineArray = line.split(',');
//       let singleObj = {};
//       const obj = lineArray.map((item, index) => {
//         if (index === 0) {
//           singleObj['date'] = item;
//         } else if (index === 1) {
//           singleObj['max'] = item;
//         } else {
//           singleObj['min'] = item;
//         }
//       });
//       result.push(singleObj);
//     }
//   };

//   await compile();
//   result.shift();
//   // res.send(result);
//   return {
//     statusCode: 200,
//     body: JSON.stringify(result),
//   };
// });

// Use our router configuration when we call /api
// app.use('/api', router);

// app.listen(PORT, () => console.log('Listening on port ' + PORT));

// module.exports.handler = serverless(app);
