
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'frankliardet',
  applicationName: 'coates-challenge-app',
  appUid: 'K23t9RGbMQCb9z7RVZ',
  orgUid: '971f6f1e-9678-452a-afc6-080146996ce2',
  deploymentUid: '6dd79685-1a9f-4c5d-8c54-7b2969247941',
  serviceName: 'coates-challenge-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'coates-challenge-serverless-dev-temperatures', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.temperatures, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}